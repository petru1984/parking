<?php
namespace App\Http\Controllers;

use App\Models\Booking;
use Illuminate\Http\Request;

class BookingController extends Controller {
// Link for test must be: http://booking.lan/?parking-name=park3&datetime-from=2021-11-11%2008:08:08&datetime-to=2021-11-31%2008:08:08&status=paid
    function fullList(){
        $getAll = Booking::get();
        $arr = [];
        foreach($getAll as $k){
           $arr[] = [
               'parking_name' => $k->parking_name,
               'datetime_from' => $k->datetime_from,
               'datetime_to' => $k->datetime_to,
               'status' => $k->status
           ];
        }

        if (count($arr) > 0) {
            return response()->json($arr);
        }else{
            return response()->json(['status' => 'No Parking booking exist']);
        }
    }

    function add(Request $request){
        if(!empty($request->input('parking-name')) && !empty($request->input('datetime-from')) && !empty($request->input('datetime-to')) && !empty($request->status)) {
            Booking::create([
                'parking_name' => $request->input('parking-name'),
                'datetime_from' => $request->input('datetime-from'),
                'datetime_to' => $request->input('datetime-to'),
                'status' => $request->status
            ]);

            return response()->json([
                'parking_name' => $request->input('parking-name'),
                'datetime_from' => $request->input('datetime-from'),
                'datetime_to' => $request->input('datetime-to'),
                'status' => $request->status
            ]);
        }else{
            return response()->json(['status' => 'parameters must not empty']);
        }
    }

    function edit(Request $request){
        if(!empty($request->input('parking-name')) && !empty($request->input('datetime-from')) && !empty($request->input('datetime-to')) && !empty($request->status)){
            $updateBokking = Booking::find($request->id);
            $updateBokking->parking_name = $request->input('parking-name');
            $updateBokking->datetime_from = $request->input('datetime-from');
            $updateBokking->datetime_to = $request->input('datetime-to');
            $updateBokking->status = $request->status;
            $updateBokking->update();

            return response()->json([
                'parking_name' => $request->input('parking-name'),
                'datetime_from' => $request->input('datetime-from'),
                'datetime_to' => $request->input('datetime-to'),
                'status' => $request->status
            ]);
      }else{
            return response()->json(['status' => 'parameters must not empty']);
        }
    }

    function delete(Request $request){
        $deleteBooking = Booking::find($request->id);
        $deleteBooking->delete();

        return response()->json(['status' => 'This Booking was deleted succesfuly']);
    }
}

?>