<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Link for test must be: http://booking.lan/?parking-name=park3&datetime-from=2021-11-11%2008:08:08&datetime-to=2021-11-31%2008:08:08&status=paid

Route::get('/booking/list', 'App\Http\Controllers\BookingController@fullList');

Route::get('/booking/add','App\Http\Controllers\BookingController@add');
Route::get('/booking/edit','App\Http\Controllers\BookingController@edit');
Route::get('/booking/delete','App\Http\Controllers\BookingController@delete');
